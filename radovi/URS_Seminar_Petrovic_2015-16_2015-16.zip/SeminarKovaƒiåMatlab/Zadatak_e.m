clear all
clc

%%unos podataka%%
poruka= 'Unesi vrijednost momenta tromosti mastera Jm i slavea Js: \n';
Jm = input(poruka);
Js = Jm;
poruka= '\nUnesi faktor prigusenja mastera bm i slavea bs: \n';
bm = input(poruka);
bs = bm;

%komunikacijsko ka�njenje
poruka= '\nUnesi komunikacijsko ka�njenje master-slave-master u sekundama: \n';
T=input(poruka);

% parametri simulacije
poruka= '\nUnesi broj diskretnih trenutaka: \n';
brtoc = input(poruka);
poruka= '\nUnesi vrijeme trajanja simulacije: \n';
tsim = input(poruka);

%predefinirane vrijednosti maksimalnog nadvi�enja sigma_m i vremena maksimuma tm
sigma_m=5;
tm=0.5;

%izra?un zeta i omega wn, potrebno za dobivanje parametara regulatora
pom=1/(((pi^2)/(log(sigma_m/100))^2)+1);
zeta=sqrt(pom);
zeta=zeta(zeta>0);
wn = pi/(tm*sqrt(1-zeta^2));


%Parametri regulatora
Kpd = Jm/2 * wn^2;
Bpd = Jm*zeta*wn - bm/2;

%unos parametara za valno upravljanje
poruka= '\nUnesi iznos valne varijable b: \n';
b=input(poruka);
poruka= '\nUnesi lomnu frekvenciju lamda: \n';
lambda=input(poruka);

Bpd = lambda*Jm;
Kpd = lambda^2*Jm;
D = lambda*Jm - bm;
R = b - lambda*Jm;
Dm = b - bm;

open_system('shema_zade');
sim('shema_zade',tsim);

figure
subplot(4,2,1), plot(t,theta_m); grid on; title('Master'); ylabel('Position');
subplot(4,2,2), plot(t,theta_s); grid on; title('Slave'); ylabel('Position');
subplot(4,2,3), plot(t,dtheta_m); grid on; ylabel('Speed');
subplot(4,2,4), plot(t,dtheta_s); grid on; ylabel('Speed');
subplot(4,2,5), plot(t,tau_m); grid on; ylabel('Torque');
subplot(4,2,6), plot(t,tau_s); grid on; ylabel('Torque');
subplot(4,2,7), plot(t,theta_m-theta_s); grid on; 
xlabel('Time (s)'); ylabel('Position diff');
subplot(4,2,8), plot(t,dtheta_m-dtheta_s); grid on; 
xlabel('Time (s)'); ylabel('Speed diff')
